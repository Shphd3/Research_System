from pathlib import Path
import zipfile,json
P=Path(__file__).resolve().parent
files=['three_models_report.md','conclusions.md','three_models_composition.csv','sir_ablation.csv','sir_intervals.csv','geometry_multi_rank.csv','readout_minimal_pair.csv','readout_summary.csv','output_covariance.csv','entropy_summary.csv','composition_intervals.csv','arxiv.json','tasks.json','provenance.json','config.json','audit.json','reproduce.sh']
for pat in ['*.py','fig*.png','fig*.pdf','*entropy.csv.gz','*partners.json']:files.extend(f.name for f in P.glob(pat))
with zipfile.ZipFile(P/'three_models_results.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=5) as z:
 for f in dict.fromkeys(files):z.write(P/f,f)
with zipfile.ZipFile(P/'three_models_results.zip') as z:assert z.testzip() is None
