from pathlib import Path
import hashlib,json,os
P=Path(__file__).resolve().parent
reg=Path('/data/250010109/Research_System/assets/catalog.json')
def entry(key,category,title,files,identity):
 for f in files: assert (P/f).is_file()
 return dict(id=key,category=category,title_cn=title,kind={'dataset':'four_leaf_arxiv_panel','analysis':'three_model_sae_interventions','representation':'top50_four_leaf_cache'}[category],payload_status='SOURCE_FILES_PRESENT',projects=['from-attention-to-search'],required_projects=[],storage_owner='MoE_Router',identity=identity,locations=[dict(path=str(P),role='primary',expected='directory',required=True,probes=[dict(path=f,expected='file') for f in files])])
pro=json.load(open(P/'provenance.json'));items=[entry('dataset_four_leaf_arxiv_1124','dataset','四领域同来源论文摘要面板',['arxiv.json','source.py','provenance.json'],pro['panels']['arxiv'])]
for m in [2,9,35]:
 items.append(entry(f'representation_three_model_four_leaf_1124_{m}b','representation',f'四领域三模型比较 {m}B 配套中层与 SAE 缓存',[f'{p}{m}.npz' for p in ['se','arxiv','task']]+[f'task_hidden{m}.npy','config.json','tasks.json'],dict(model=pro['models'][str(m)],panels=['dataset_four_leaf_se_1124_scaling','dataset_four_leaf_arxiv_1124'])))
items.append(entry('analysis_three_model_sir_1124','analysis','三模型双来源的领域组成、去干扰和真实输出对照',['three_models_report.md','three_models_composition.csv','sir_ablation.csv','geometry_multi_rank.csv','readout_minimal_pair.csv','audit.json','sir_intervals.csv','output_covariance.csv'],dict(seed=1125,targets_per_leaf=8,paired_test_backgrounds=32,parents=['dataset_four_leaf_se_1124_scaling','dataset_four_leaf_arxiv_1124'])))
s=reg.read_text();db={a['id']:a for a in json.loads(s)['assets']};add=[]
for a in items:
 if a['id'] in db:assert db[a['id']]==a
 else:add.append('\n'.join('    '+line for line in json.dumps(a,ensure_ascii=False,indent=2).splitlines()))
if add:
 tag='  "assets": [\n';assert s.count(tag)==1
 tmp=reg.with_name('catalog.three_models.tmp');tmp.write_text(s.replace(tag,tag+',\n'.join(add)+',\n',1));assert reg.read_text()==s;os.replace(tmp,reg)
