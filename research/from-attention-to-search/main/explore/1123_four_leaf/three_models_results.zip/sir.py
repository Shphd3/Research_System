from data import *
from model import sae
import torch,pandas as pd,sys
T=lambda x:torch.as_tensor(x,device='cuda')
def moments(Z,w):
 return np.maximum(0,Z.power(2).T@w-(Z.T@w)**2)
def vari(x,w):return ((x-w@x)**2)@w
def covar(x,y,w):return ((x-w@x)*(y-w@y))@w
def gram(dec,j,v):
 grams=[]
 for jj,vv in zip(T(j.astype('int64')).split(24),T(v).split(24)):
  a=dec.T[jj]*vv[:,:,None];grams.append(a@a.transpose(1,2))
 return torch.cat(grams)
def random_control(G,mask,eligible,generator,draws=128):
 # Sample fixed-size subsets. Use independent uniform subset proposals.
 # Exclude the original set whenever a distinct set is possible.
 out=[];energy=[];matched=[]
 for start in range(0,len(G),32):
  g=G[start:start+32];fixed=T(mask[start:start+32]);ok=T(eligible[start:start+32]);k=fixed.sum(-1);n=len(g)
  target=((fixed.float()[:,None,:]@g)*fixed[:,None,:]).sum((1,2))
  scores=torch.rand(n,draws,50,device='cuda',generator=generator).masked_fill(~ok[:,None,:],2)
  opt=(scores.argsort(-1).argsort(-1)<k[:,None,None])
  can=(k>0)&(ok.sum(-1)>k)
  opt=opt.float();e=((opt@g)*opt).sum(-1);cost=(e-target[:,None]).abs()
  cost+=((opt==fixed[:,None,:]).all(-1)&can[:,None])*1e20
  ix=cost.argmin(-1);rows=torch.arange(n,device='cuda');out.append(opt[rows,ix].bool().cpu().numpy());energy.extend(target.cpu().numpy());matched.extend(e[rows,ix].cpu().numpy())
 return np.concatenate(out),np.array(energy),np.array(matched)
def run(m,panel):
 a=Panel(m,panel);prefix=str(P/f'{panel}{m}');frozen=np.load(prefix+'roles.npz');role,own,B,ct,enrich=[frozen[k] for k in ['role','own','B','ct','enrich']]
 s=sae(m);dec=s['W_dec'].contiguous();norm=dec.norm(dim=0).cpu().numpy();D=len(dec);gen=torch.Generator(device='cuda').manual_seed(1125);rows=[];shared={};blockstats=[]
 for li,l in enumerate(LEAVES):
  bi=a.ids('build',l);ti=a.ids('test',l); bt=a.tokens(bi);tt=a.tokens(ti);bw=a.weight(bi);w=a.weight(ti);bz=a.Z[bt];z=a.Z[tt];bv=moments(bz,bw);tv=moments(z,w); mu=bz.T@bw
  fs=np.flatnonzero((role==2)&(own==li)&(ct>=20));fs=fs[np.lexsort((fs,-ct[fs]))[:8]]
  if not len(fs):continue
  u=dec[:,fs]/T(norm[fs]); C=(dec.T@u).cpu().numpy();C[fs,np.arange(len(fs))]=0
  buildproj=bz@C;cross=bz.T@(bw[:,None]*(buildproj-bw@buildproj));score=C*(cross-C*bv[:,None]);score[fs,np.arange(len(fs))]=0
  aggregate=(score/np.maximum(np.abs(score).sum(0),1e-30)).sum(1);shared[l]=np.flatnonzero(aggregate>0)[np.argsort(-aggregate[aggregate>0],kind='stable')[:8]].tolist()
  j=a.j.reshape(-1,50)[tt];v=a.v.reshape(-1,50)[tt];h=np.concatenate([a.ht[a.test_index[i],:a.n[i]] for i in ti]);G=gram(dec,j,v)
  proj=h@u.cpu().numpy();bias=(s['b_dec']@u).cpu().numpy();ownval=z[:,fs].toarray()*norm[fs]
  allproj=z@C;res=proj-bias-allproj-ownval
  for col,f in enumerate(fs):
   b=C[:,col];base=allproj[:,col];resid=res[:,col];o=ownval[:,col];S=vari(o,w);I=vari(base,w);full=vari(base+resid,w);rv=vari(resid,w)
   selected=np.flatnonzero(score[:,col]>0);kp=selected[np.argsort(-score[selected,col],kind='stable')[:8]]
   cond={'raw':np.zeros(a.W,bool),'remove_upper_A':role<=1,'remove_upper_B':B,'remove_other_leaf':(role==2)&(own!=li),'remove_top_cov_partners':np.isin(np.arange(a.W),kp),'remove_cross_domain':(role==3)&~enrich}
   for name,mask in cond.items():
    mask=mask.copy();mask[f]=False;fixed=mask[j]&(v>0)
    if name=='raw':conditions=[('raw',fixed,np.zeros(len(w)),np.zeros(len(w)))]
    else:
     rand,e,re=random_control(G,fixed,(j!=f)&(v>0),gen)
     alpha=np.sqrt(np.divide(e,re,out=np.zeros_like(e),where=re>0));assert not np.any((e>1e-12)&(re<=0))
     conditions=[(name,fixed,e,e),(name+'_random',rand,e,re),(name+'_random_scaled',rand*alpha[:,None],e,re*alpha**2)]
    for nm,delmask,ref,actual in conditions:
     t=base-np.sum(v*b[j]*delmask,axis=1);total=vari(t,w);whole=vari(t+resid,w)
     if '_random' in nm:
      vv=v*(1-delmask.astype(float));mean=np.bincount(j.ravel(),weights=(vv*w[:,None]).ravel(),minlength=a.W);va=np.maximum(0,np.bincount(j.ravel(),weights=(vv**2*w[:,None]).ravel(),minlength=a.W)-mean**2)
     else:va=tv*(~mask)
     diag=va@(b.astype('d')**2);iso=(va@(norm.astype('d')**2)-va[f]*norm[f]**2)/D
     active=ref>1e-14;err=abs(actual[active]-ref[active])/ref[active] if active.any() else np.array([0.])
     lens=a.n[ti];offset=np.r_[0,lens.cumsum()[:-1]];mom=lambda x:np.add.reduceat(x,offset)/lens
     blockstats.append(np.array([mom(t),mom(t**2),mom(t+resid),mom((t+resid)**2)]))
     rows.append(dict(model=m,panel=panel,leaf=l,f=f,condition=nm,S=S,I_total=total,I_iso=iso,I_diag=diag,I_off=total-diag,residual_var=rv,cross_cov=2*covar(t,resid,w),I_full=whole,rho_S=1. if S>0 else np.nan,rho_I=total/I,rho_I_full=whole/full,gain=I/total if S>0 else np.nan,gain_full=full/whole if S>0 else np.nan,energy=w@actual,matched_active_10pct=(err<=.10).mean() if active.any() else np.nan,energy_error_median=np.median(err) if active.any() else np.nan,active_positions=active.sum(),positions=len(w),documents=len(ti),target_hits=z[:,f].nnz,partners=','.join(map(str,kp)),amplification=total/diag if diag else np.nan))
     assert np.isclose(whole,total+rv+2*covar(t,resid,w),atol=1e-7,rtol=1e-5)
  print(m,panel,l,'targets',fs,flush=True)
  np.save(prefix+'docmom.npy',np.stack(blockstats));pd.DataFrame(rows).to_csv(prefix+'sir.csv',index=False);(P/f'{panel}{m}partners.json').write_text(json.dumps(shared))
if __name__=='__main__':
 with torch.inference_mode():run(int(sys.argv[1]),sys.argv[2])
