from pathlib import Path
import pandas as pd,numpy as np,json
P=Path(__file__).resolve().parent
read=lambda name:pd.read_csv(P/(name+'.csv'));c=read('three_models_composition');x=read('sir_ablation');ci=read('sir_intervals');g=read('geometry_multi_rank');q=read('readout_summary');o=read('output_covariance');e=read('entropy_summary');cmp=read('composition_intervals')
def table(d):return d.to_markdown(index=False,floatfmt='.3f')
def names(d):return d.rename(columns={'model':'模型（B）','panel':'语料','role':'类别','rho_I':'剩余干扰（SAE）','rho_I_full':'剩余干扰（含残差）','gain_full':'净增益（含残差）','amplification':'共同激活放大倍数'})
roles={'root':'通用','parent':'学科','leaf':'单领域偏好','soft_shared':'其他有支持','low_support':'样本不足'}
conds={'raw':'原始','remove_upper_A':'去标签上层','remove_upper_B':'去统计上层','remove_other_leaf':'去另外三域','remove_top_cov_partners':'去8个共变伙伴','remove_cross_domain':'去严格跨域组'}
def one(df,p,m,n):return df[(df.panel==p)&(df.model==m)&(df.condition==n)].iloc[0]
def bands(d):return d.apply(lambda r:f'{r.vs_equal_energy:.2f} [{r.rel_lo:.2f}, {r.rel_hi:.2f}]',axis=1)
c0=c[c.leaf=='all'].pivot(index=['panel','model'],columns='role',values='per_token')[list(roles)].rename(columns=roles).reset_index()
ref=x[x.condition=='raw'].copy();ref['方向偏离']=ref.I_diag/ref.I_iso;ref['共同激活放大']=ref.I_total/ref.I_diag;ref['合计相对随机方向']=ref.I_total/ref.I_iso
rawtable=ref.groupby(['panel','model'])[['方向偏离','共同激活放大','合计相对随机方向']].median().reset_index()
main=x[x.condition.isin(conds)].groupby(['panel','model','condition']).median(numeric_only=True).reset_index();bc=ci[(ci.space=='full')&(ci.condition.isin(conds))&(ci.condition!='raw')].copy();bc['相对等能量随机［95%区间］']=bands(bc)
eff=main.merge(bc[['panel','model','condition','相对等能量随机［95%区间］']],on=['panel','model','condition']);eff['处理']=eff.condition.map(conds)
rq=q[q.condition=='raw'];d35=q[(q.model==35)&q.condition.isin(['remove_other_leaf','remove_top_cov_partners'])].copy()
d35['处理']=d35.condition.map(conds)
cr=cmp[cmp.group=='leaf'][['panel','comparison','difference_pp','lo_pp','hi_pp']]
geo=g[(g.source.isin(['QM','SM'])&g.basis.isin(['AA','GT']))|(g.basis.isin(['QM','SM'])&g.source.isin(['AA','GT']))].copy()
gt=geo[geo.condition=='raw'].groupby(['panel','model','space','rank'])[['coverage','self_coverage','linear_CKA','mean_angle_deg']].mean().reset_index()
summ=geo[geo['rank']==16].groupby(['panel','model','space','condition']).coverage.mean().unstack().reset_index()
fout=o[(o.condition=='raw')&(o.space=='final_correct_logit')].groupby('model').amplification.agg(['min','max']).reset_index()
out=['# 三个冻结模型中，哪些成分值得隔离？','目标是在保住领域细节的前提下减少落到同一方向的其他波动，并检验模型是否因此更容易给出正确答案。按领域归类、沿方向测方差和在真实答案上做干预，分别回答三个问题。',
'## 组会结论', (P/'conclusions.md').read_text() if (P/'conclusions.md').exists() else '见实测表。',
'## 1　MoE 的组成与两个稠密模型有何异同？','表中是每个词实际亮起的约 50 个特征里，各类平均占几个。每个模型、每份语料单独用建图文档标记特征；测试时复用名单。单领域偏好允许同一个特征在其他领域出现。',table(names(c0)),
'MoE 减去两种稠密模型的单领域偏好激活占比差，单位为百分点。以下按相同文档配对、在每个领域内重抽 32 篇，区别于总激活数的汇总。',table(cr),
'测试集中至少亮起 20 次的严格跨域特征，列出它的激活落在四个领域时有多均匀。熵为 1 表示四域均匀，为 0 表示测试事件集中在一域。完整逐编号分布见每一组的 entropy.csv.gz。',table(e[(e.scope=='strict_cross_domain')&(e.min_test_hits==20)][['panel','model','features','q25','median','q75']]),
'![Composition](fig1_composition.png)','## 2　删哪些特征有独立于删除能量的收益？',
'沿每个目标特征的解码方向，先估计随机方向会带来多少波动，再换成真实方向，最后加上特征一起亮起的影响。下表分别是三个量之比的目标中位数，三列分别取中位数，所以前两列的乘积可以略异于第三列。',table(names(rawtable)),'![Leakage relative to isotropy](fig2_leakage.png)',
'目标自身的 SAE 分量在每次删除中都受保护，因此对所有实测目标，信号保留率为 1。模型是否保留了可用知识，另用答案验证。下表的 0.75 表示其他成分只剩原来 75% 的波动；净增益 1.33 表示信干比为原来的 1.33 倍。最后一列大于 1 表示按特征选择优于同位置、相同删除能量的随机方向。全表同时提供纯坐标随机删除的匹配误差。',table(names(eff[['panel','model','处理','rho_I','rho_I_full','gain_full','相对等能量随机［95%区间］']])),'![Signal-to-interference comparison](fig3_gain.png)',
'### 哪种处理压低了协方差？','以下为干扰总方差除以仅保留对角项的方差，每列取目标中位数。这个比值回答是否共同放大；绝对非对角项和总剩余干扰可分别在明细表核对。',table(main.pivot(index=['panel','model'],columns='condition',values='amplification').rename(columns=conds).reset_index()),
'## 3　几何变化能否传到答案？','取同一测试向量投影到另一领域的训练主方向，给出跨学科双向覆盖的平均值。隐藏空间在原向量上减去解码贡献，SAE 空间直接将相应坐标清零。四个秩的方向角、同叶覆盖和 CKA 均已保存。下面列出秩 16。',table(summ.rename(columns=conds)),
'原始表征各秩的方向角（度）、同叶与跨叶覆盖、CKA。角度小表示方向接近；CKA 在同一批测试位置上，比较两套主方向打分的变化是否一致。',table(gt),
'32 对同叶量子题只翻转算符。例：固定位置表象，问位置算符和动量算符的作用，答案分别为乘法和微分。训练集有 24 个背景、两种措辞，8 个独立背景用于选正则；测试有 32 个新背景、两种新措辞，每个背景只取一对。以下 NLL 越低越好，原生概率只在两个指定答案之间归一化。',table(rq[['model','raw_gate','probe_acc','probe_nll','native_acc','native_nll']]),
'同时达到 80% 正确率和 0.45 对数损失的模型进入固定探针干预。校准集选择的探针在干预时保持冻结。下表 Δ 为处理后减原始，随机差为处理后减等能量随机，负值是改善。',table(d35[['处理','delta_probe_nll','delta_probe_nll_lo','delta_probe_nll_hi','vs_random_probe_nll','vs_random_probe_nll_lo','vs_random_probe_nll_hi','delta_native_nll','delta_native_nll_lo','delta_native_nll_hi','vs_random_native_nll','vs_random_native_nll_lo','vs_random_native_nll_hi']]),
'将两个正确词分别测量，中层用对应的输出权重行作投影，最终层则把同一位置的 50 个特征依次加回、每次计算真实答案 logit。两种加回次序下，相邻 logit 增量的总和都严格回到原始 logit 与全删除 logit 之差。每个编号分到的增量随次序变化。下面给出两种答案和两种次序对应的放大倍数范围。',table(fout),
'## 数据、规则与复算',
'四域固定为量子力学、统计物理、抽象代数、图论。Stack Exchange 每域 512/32/32 篇建图、校准、测试；arXiv 每域 256/32/32。arXiv 取同一来源、同一年份（2019）的英文摘要，按首个分类选 quant-ph、cond-mat.stat-mech、math.RA/math.GR、math.CO；图论再要求标题出现 graph/graphs。输入只有清洗后的摘要，标题只用于筛样。类别是领域的代理，arXiv 与问答的体裁和建图样本量也随面板变化。数据版本、文件摘要和拆分计数见 provenance.json。',
'按规则 A，先把文档分为四域，再给特征编号归类。通用要求四域激活率均 ≥1%、文档覆盖均 ≥50%。学科要求同学科两个领域覆盖均 ≥30%、激活率均 ≥0.5%，其中较低的激活率仍至少是另一学科最大值的两倍。单领域偏好要求最高激活率至少为第二名的两倍、该域覆盖 ≥20%。依次判定；剩下的少于 20 次记样本不足。其他有支持再分为跨域组及虽达两倍但文档覆盖不足的编号；跨域删除只取前者。',
'规则 B 完全根据同一个词上哪些特征一起亮起统计。两者各至少亮 200 次、共现至少 20 次。较少见的特征亮起时至少 80% 同时有较常见者；反过来不超过 50%，且较常见者至少常见两倍。用所有这样的上邻居的并集作上层。只测全局上层时，传递约简前后并集相同。本轮并列的是 A 的标签上层和 B 的统计上层。',
'模型分别为 2B L11、9B L15、35B-A3B L19（层号从零开始）。三者均在中段全注意力块之后、下一块之前读取。隐藏维为 2048/4096/2048，字典宽为 32768/65536/32768，配套 SAE 均取原生 Top-50 后的正值。MoE 的路由专家与 SAE 特征是不同对象。每个模型的大小、层和 SAE 随检查点一起变化，因此可跨来源比较三套系统的观测，架构归因仍需受控比较。',
'目标在建图集内固定，为每域最常出现的 8 个单领域偏好特征。给定单位目标方向 u，目标信号为自身解码投影的方差。I_diag 将其他特征投影方差逐项相加；I_total 先加投影再取方差；I_off 是二者之差。I_iso 把平方方向内积换成 1/D。原隐藏空间的完整干扰还要加入 SAE 未重建残差的方差和两倍交叉协方差。对同一域按文档等权取方差。按特征取中位数，区间在各叶内重抽整篇测试文档，同一抽样用于所有处理，固定已选的特征和名单。',
'选共变伙伴时，在目标领域的建图文档上计算每个其他特征与剩余来源的带符号投影协方差之和；取正值最大的 8 个。答题需使用同一张名单，故用量子力学的 8 个目标平均各自归一化的贡献排名，取固定 8 个。随机对照每位置保持删除数量、保护目标，在 128 组随机坐标中选解码能量最接近者。另将随机删除向量按长度缩放至与实际删除严格等能量，独立列为 random_scaled；缩放对应连续扰动。删除能量是完整解码向量差的平方范数。',
'几何使用第 24/32/40/48 个零基位置，训练均值用于中心化，每种处理单独估计主方向，随机化 PCA 固定种子 1125。外叶和伙伴的几何比较均对两边使用同一个并集删除名单。计算线性 CKA 时两套训练基同时作用于全部相同的测试文档位置。探针的编辑只作用在最后的答案前位置，原生答案由完整后半模型实际重算。',
'复现命令为 `bash reproduce.sh`。所需项目依赖、原面板与已登记冻结权重见 config.json、provenance.json 和上一级 scaling_1124。audit.json 记录重编码、独立解码回放、零删除、完整方差、单词翻转与原生读出的核查。同题同词方向与上一轮稠密模型原生 margin 回放的最大绝对差分别为 0.125、0.0625，受 BF16 批处理数值差异影响；同轮处理与随机对照使用相同执行方式。三个 PDF 提供矢量图，PNG 使用英文标签与 500 dpi。']
(P/'three_models_report.md').write_text('\n\n'.join(out)+'\n')
