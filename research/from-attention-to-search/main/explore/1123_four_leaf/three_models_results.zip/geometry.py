from data import *
from model import sae
import itertools,torch,pandas as pd,sys
from scipy.sparse.linalg import LinearOperator
from sklearn.utils.extmath import randomized_svd
T=lambda x:torch.as_tensor(x,device='cuda')
def bases(X):
 if sparse.issparse(X):
  mu=np.asarray(X.mean(0)).ravel();dot=lambda v:X@v-mu@v
  def rdot(v):return X.T@v-mu[:,None]*v.sum(0)
  op=LinearOperator(X.shape,matmat=dot,rmatmat=rdot,matvec=lambda v:dot(v.reshape(-1,1)).ravel(),rmatvec=lambda v:rdot(v.reshape(-1,1)).ravel(),dtype=np.float32)
  _,v,vt=randomized_svd(op,64,n_iter=5,n_oversamples=24,random_state=1125,transpose=False);return T(vt.T.copy()),mu
 x=T(X);mu=x.mean(0);x=x-mu;torch.manual_seed(1125);q,_,v=torch.pca_lowrank(x,q=88,center=False,niter=5);return v[:,:64].contiguous(),mu.cpu().numpy()
def run(m,panel,extra=False):
 a=Panel(m,panel);p=str(P/f'{panel}{m}');r=np.load(p+'roles.npz');role,own=r['role'],r['own'];dec=sae(m)['W_dec'].T.contiguous();pos=[24,32,40,48];assert a.n.min()>48
 z=a.csr(a.j[:,pos],a.v[:,pos]);h=a.h4.reshape(-1,a.h4.shape[-1]);rows=[];test=a.ids('test');train=a.ids('build')
 def positions(ids):return (ids[:,None]*4+np.arange(4)).ravel()
 anchors=positions(test);zeros=np.zeros(a.W,bool)
 masks=[(nm,mk,range(4)) for nm,mk in [('raw',zeros),('remove_upper_A',role<=1),('remove_upper_B',r['B']),('remove_cross_domain',(role==3)&~r['enrich'])]]
 if extra:
  partners=json.load(open(p+'partners.json'));masks=[('remove_other_leaf_pair_union',role==2,range(4))]
  for i,k in itertools.combinations(range(4),2):
   ids=set(partners[LEAVES[i]])|set(partners[LEAVES[k]])
   masks.append(('remove_top_cov_pair_union',np.isin(np.arange(a.W),list(ids)),[i,k]))
 for name,mask,which in masks:
  sel=np.flatnonzero(mask); x=h.copy()
  if len(sel):
   # Iterate tokens to bound the dense temporary decoder product.
   zm=z[:,sel].tocsr();w=dec[sel].cpu().numpy()
   for i in range(0,len(x),256):x[i:i+256]-=zm[i:i+256]@w
  zz=z.copy();zz.data*=~mask[zz.indices];zz.eliminate_zeros()
  for space,feat in [('hidden',x),('sae',zz)]:
   qa={};mu={};scores={}
   for i in which:
    l=LEAVES[i];ids=positions(a.ids('build',l));q,mean=bases(feat[ids]);qa[i]=q;mu[i]=mean
    vals=feat[anchors];proj=vals@q.cpu().numpy();scores[i]=T(proj)
   for i,k in itertools.combinations(which,2):
    dot=qa[i].T@qa[k];ia=np.repeat(a.l[test]==LEAVES[i],4);ka=np.repeat(a.l[test]==LEAVES[k],4)
    for rank in [8,16,32,64]:
     ang=torch.rad2deg(torch.acos(torch.linalg.svdvals(dot[:rank,:rank]).clamp(0,1))).cpu().numpy()
     s1=scores[i][:,:rank];s2=scores[k][:,:rank];v1=s1-s1.mean(0);v2=s2-s2.mean(0);cka=((v1.T@v2).norm()**2/((v1.T@v1).norm()*(v2.T@v2).norm())).item()
     for row,col,ix in [(i,k,ia),(k,i,ka)]:
      fv=feat[anchors[ix]];mean=mu[row]
      energy=(fv.multiply(fv).sum()-2*(fv@mean).sum()+len(anchors[ix])*(mean@mean)) if sparse.issparse(fv) else np.sum((fv-mean)**2)
      def coverage(j):return ((scores[j][ix,:rank]-T(mean)@qa[j][:,:rank]).square().sum()/float(energy)).item()
      rows.append(dict(model=m,panel=panel,condition=name,space=space,source=LEAVES[row],basis=LEAVES[col],rank=rank,coverage=coverage(col),self_coverage=coverage(row),total_energy=energy,mean_angle_deg=ang.mean(),angles_deg=' '.join(map(str,ang)),mean_cos2=np.mean(np.cos(np.deg2rad(ang))**2),linear_CKA=cka,anchor_docs=len(test)))
   print(m,panel,name,space,flush=True);pd.DataFrame(rows).to_csv(p+('extra_geometry.csv' if extra else 'geometry.csv'),index=False)
if __name__=='__main__':
 with torch.inference_mode():run(int(sys.argv[1]),sys.argv[2],len(sys.argv)>3)
