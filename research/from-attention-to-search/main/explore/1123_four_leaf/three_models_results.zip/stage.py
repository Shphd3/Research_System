from pathlib import Path
import shutil, json, concurrent.futures, os
Q=Path('/mnt/bucket/109_cache_dir/model_cache/Qwen'); dest=Path('/tmp/qm_three_weights')
def stage(p):
 f=dest/p.parent.name/p.name;f.parent.mkdir(exist_ok=True,parents=True)
 if f.exists() and f.stat().st_size==p.stat().st_size:return
 t=f.with_suffix(f.suffix+'.part');shutil.copyfile(p,t);assert t.stat().st_size==p.stat().st_size;os.replace(t,f);print(f,flush=True)
for name in ['Qwen3.5-35B-A3B-Base','Qwen3.5-2B-Base','Qwen3.5-9B-Base']:
 with concurrent.futures.ThreadPoolExecutor(6) as pool:list(pool.map(stage,sorted((Q/name).glob('*.safetensors'))))
