from pathlib import Path
import numpy as np,pandas as pd,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
P=Path(__file__).resolve().parent;M=[2,9,35];PS=['se','arxiv'];LEAVES=['QM','SM','AA','GT']
def combine(suffix,dest):
 df=pd.concat([pd.read_csv(P/f'{p}{m}{suffix}.csv') for p in PS for m in M],ignore_index=True);df.to_csv(P/dest,index=False);return df
def bootstrap(sir):
 rows=[];rng=np.random.default_rng(1125);nb=1200
 for (p,m),a in sir.groupby(['panel','model'],sort=False):
  a=a.reset_index(drop=True);mom=np.load(P/f'{p}{m}docmom.npy');assert len(a)==len(mom)
  feat=a[a.condition=='raw'][['leaf','f']];conds=a.condition.unique();ld={}
  for leaf in LEAVES:ld[leaf]=rng.multinomial(32,np.ones(32)/32,size=nb)/32
  results={}
  for nm in conds:
   group=a[a.condition==nm];assert np.array_equal(group.f,feat.f)
   data=[];point=[]
   for leaf,sub in group.groupby('leaf',sort=False):
    x=mom[sub.index];bs=ld[leaf];sm=x@bs.T;vv=np.stack((sm[:,1]-sm[:,0]**2,sm[:,3]-sm[:,2]**2),axis=1);data.append(vv)
    point.append(sub[['I_total','I_full']].to_numpy())
   results[nm]=np.concatenate(data),np.concatenate(point)
  for nm in conds:
   bs,pt=results[nm];bs0,pt0=results['raw'];gain=bs0/bs;gp=pt0/pt
   for i,kind in enumerate(['decoded','full']):
    b=np.median(gain[:,i],axis=0);mp=np.median(gp[:,i]);lo,hi=np.quantile(b,[.025,.975]);rec=dict(panel=p,model=m,condition=nm,space=kind,median_gain=mp,lo=lo,hi=hi,targets=len(gp))
    if nm+'_random_scaled' in results:
     rb,rp=results[nm+'_random_scaled'];rel=rb[:,i]/bs[:,i];obs=rp[:,i]/pt[:,i];lo,hi=np.quantile(np.median(rel,axis=0),[.025,.975]);rec.update(vs_equal_energy=np.median(obs),rel_lo=lo,rel_hi=hi)
    rows.append(rec)
 return pd.DataFrame(rows)
def plot(comp,sir,gains):
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,'axes.labelsize':8,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none','axes.linewidth':.7,'figure.dpi':120})
 labels=['2B dense','9B dense','35B-A3B MoE'];colors=['#436795','#78A9C3','#E09C4F','#52A390','#D6DCE2'];panels=['Stack Exchange','arXiv abstracts'];roles=['root','parent','leaf','soft_shared','low_support']
 def save(fig,name):fig.savefig(P/(name+'.png'),dpi=500,bbox_inches='tight',pad_inches=.07);fig.savefig(P/(name+'.pdf'),bbox_inches='tight',pad_inches=.07);plt.close(fig)
 f,axs=plt.subplots(1,2,figsize=(7.2,2.65),sharex=True,sharey=True)
 for ax,p,pt in zip(axs,PS,panels):
  ax.set_title(pt);bottom=np.zeros(3)
  for r,c in zip(roles,colors):
   v=comp[(comp.leaf=='all')&(comp.role==r)&(comp.panel==p)].set_index('model').loc[M,'share'].values*100
   ax.barh(range(3),v,left=bottom,color=c,height=.55);bottom+=v
  ax.set(yticks=range(3),yticklabels=labels,xlabel='Share of activation events (%)',xlim=(0,100))
 axs[0].invert_yaxis();f.legend([Patch(facecolor=c) for c in colors],['General','Discipline','Leaf-enriched','Other supported','Low support'],ncol=5,loc='lower center',frameon=False,columnspacing=1);f.tight_layout(rect=[0,.13,1,1]);save(f,'fig1_composition')
 f,axs=plt.subplots(1,2,figsize=(7.1,3.0),sharey=True)
 for ax,p,pt in zip(axs,PS,panels):
  for i,m in enumerate(M):
   g=sir[(sir.panel==p)&(sir.model==m)&(sir.condition=='raw')];v=np.sort(g.I_total/g.I_iso);jitter=np.random.default_rng(m).uniform(-.14,.14,len(v));ax.scatter(i+jitter,v,color=colors[[0,3,2][i]],alpha=.7,s=10,linewidths=0);ax.plot([i-.22,i+.22],[np.median(v)]*2,color='black',lw=1.6)
  ax.axhline(1,lw=.75,ls='--',color='.4');ax.set(xticks=range(3),xticklabels=labels,title=pt,yscale='log');ax.tick_params(axis='x',labelrotation=13)
 axs[0].set_ylabel('Decoded interference / isotropic prediction');f.tight_layout();save(f,'fig2_leakage')
 f,axs=plt.subplots(2,2,figsize=(7.25,5.4),sharey=True);names=['remove_upper_A','remove_upper_B','remove_other_leaf','remove_top_cov_partners','remove_cross_domain']
 for col,(p,pt) in enumerate(zip(PS,panels)):
  for ri,(metric,low,high,title) in enumerate([('median_gain','lo','hi','Gain relative to raw'),('vs_equal_energy','rel_lo','rel_hi','Gain relative to equal-energy random')]):
   ax=axs[ri,col]
   for i,m in enumerate(M):
    sub=gains[(gains.model==m)&(gains.panel==p)&(gains.space=='full')].set_index('condition').loc[names];v=sub[metric].values
    ax.errorbar(v,np.arange(5)+(i-1)*.17,xerr=np.maximum(0,np.stack([v-sub[low],sub[high]-v])),fmt=['o','s','^'][i],ms=4,color=colors[[0,3,2][i]],capsize=2,lw=1,label=labels[i])
   ax.axvline(1,color='.45',ls='--',lw=.8);ax.set(yticks=range(5),yticklabels=['Upper (labels)','Upper (inclusion)','Other leaves','Covariance partners','Cross-domain'],xlabel=title+' (×)',title=pt if ri==0 else '');ax.grid(axis='x',alpha=.16)
 for ri in [0,1]:
  left=min(a.get_xlim()[0] for a in axs[ri]);right=max(a.get_xlim()[1] for a in axs[ri])
  for ax in axs[ri]:ax.set_xlim(left,right)
 axs[0,0].invert_yaxis();f.legend(*axs[0,0].get_legend_handles_labels(),ncol=3,loc='lower center',frameon=False);f.tight_layout(rect=[0,.06,1,1]);save(f,'fig3_gain')
def main():
 c=combine('composition','three_models_composition.csv');s=combine('sir','sir_ablation.csv');g=combine('geometry','geometry_multi_rank.csv');extra=pd.concat([pd.read_csv(P/f'{p}{m}extra_geometry.csv') for p in PS for m in M]);pd.concat([g,extra],ignore_index=True).to_csv(P/'geometry_multi_rank.csv',index=False);b=bootstrap(s);b.to_csv(P/'sir_intervals.csv',index=False)
 d=pd.concat([pd.read_csv(P/f'readout{m}.csv') for m in M]);d.to_csv(P/'readout_minimal_pair.csv',index=False);rows=[]
 for m,group in d.groupby('model'):
  raw=group[group.condition=='raw'].sort_values(['doc','operator']); rng=np.random.default_rng(1125);w=rng.multinomial(32,np.ones(32)/32,size=2000)/32
  for nm,x in group.groupby('condition'):
   x=x.sort_values(['doc','operator']);assert np.array_equal(x.doc,raw.doc);r=dict(model=m,condition=nm,docs=x.doc.nunique(),raw_gate=x.raw_probe_gate.iloc[0])
   for metric in ['native_nll','native_acc','probe_nll','probe_acc']:
    v=x[metric].to_numpy().reshape(-1,2).mean(1);r[metric]=v.mean();r[metric+'_lo'],r[metric+'_hi']=np.quantile(w@v,[.025,.975]);ref=raw[metric].to_numpy().reshape(-1,2).mean(1);dv=v-ref;r['delta_'+metric]=dv.mean();r['delta_'+metric+'_lo'],r['delta_'+metric+'_hi']=np.quantile(w@dv,[.025,.975])
    if nm+'_random_scaled' in set(group.condition):
     rnd=group[group.condition==nm+'_random_scaled'].sort_values(['doc','operator'])[metric].to_numpy().reshape(-1,2).mean(1);dv=v-rnd;r['vs_random_'+metric]=dv.mean();r['vs_random_'+metric+'_lo'],r['vs_random_'+metric+'_hi']=np.quantile(w@dv,[.025,.975])
   rows.append(r)
 pd.DataFrame(rows).to_csv(P/'readout_summary.csv',index=False);pd.concat([pd.read_csv(P/f'output_cov{m}.csv') for m in M]).to_csv(P/'output_covariance.csv',index=False);plot(c,s,b)
if __name__=='__main__':main()
