from data import *
import pandas as pd
def classify(a):
 q=[];coverage=[];ct=np.zeros(a.W)
 for l in LEAVES:
  ids=a.ids('build',l);hits,rate=a.counts(ids);ct+=hits;q.append(rate)
  seen=np.zeros(a.W)
  for i in ids:seen[np.unique(a.j[i,:a.n[i]][a.v[i,:a.n[i]]>0])]+=1
  coverage.append(seen/len(ids))
 q=np.asarray(q);cov=np.asarray(coverage);own=q.argmax(0);root=((q>=.01)&(cov>=.5)).all(0);parent=np.zeros(a.W,bool)
 for i,k in [(0,2),(2,0)]:parent|=(cov[i:i+2].min(0)>=.3)&(q[i:i+2].min(0)>=.005)&(q[i:i+2].min(0)>=2*q[k:k+2].max(0))
 best=np.sort(q,axis=0);enrich=(best[-1]>0)&(best[-1]>=2*best[-2]);leaf=enrich&(cov[own,np.arange(a.W)]>=.2)
 role=np.select([root,parent,leaf,ct<20],[0,1,2,4],default=3)
 build=a.X[a.tokens(a.ids('build'))];cs=np.flatnonzero(ct>=200);y=build[:,cs].tocsc();upper=np.zeros(a.W,bool);edge=0
 for i in range(0,len(cs),192):
  co=(y[:,i:i+192].T@y).tocoo();c=cs[i+co.row];u=cs[co.col];n=co.data
  ok=(n>=20)&(n>=.8*ct[c])&(n<=.5*ct[u])&(ct[u]>=2*ct[c]);upper[u[ok]]=True;edge+=ok.sum()
 if a.panel=='se' and a.m in (2,9):
  prev=pd.read_csv(R/f'r{a.m}/features512.csv.gz');assert np.array_equal(prev.group, np.array(CATS)[role]);assert np.array_equal(np.flatnonzero(upper),json.load(open(R/f'r{a.m}/config.json'))['512']['B'])
 out=P/f'{a.panel}{a.m}';np.savez(str(out)+'roles.npz',role=role,own=own,B=upper,ct=ct,enrich=enrich)
 rates=np.array([a.counts(a.ids('test',l))[1] for l in LEAVES]);prob=rates/np.maximum(rates.sum(0),1e-30);entropy=-(prob*np.log(np.maximum(prob,1e-30))).sum(0)/np.log(4)
 te=a.ids('test');hits,_=a.counts(te);rows=[]
 for l in ['all']+LEAVES:
  ix=a.ids('test',None if l=='all' else l);cnt,_=a.counts(ix);n=a.n[ix].sum()
  for k,cat in enumerate(CATS):
   mask=role==k;rows.append(dict(model=a.m,panel=a.panel,leaf=l,role=cat,features=mask.sum(),docs=len(ix),tokens=n,events=int(cnt[mask].sum()),share=cnt[mask].sum()/cnt.sum(),per_token=cnt[mask].sum()/n,hifer_edges=edge,hifer_upper=upper.sum(),coverage_only_events=int(cnt[mask&enrich].sum()) if k==3 else 0))
 pd.DataFrame(rows).to_csv(str(out)+'composition.csv',index=False)
 sel=(role==3)&(hits>0);pd.DataFrame(dict(feature_id=np.flatnonzero(sel),hits=hits[sel],test_entropy=entropy[sel],strict=~enrich[sel],**{l:prob[i,sel] for i,l in enumerate(LEAVES)})).to_csv(str(out)+'entropy.csv.gz',index=False)
if __name__=='__main__':
 import sys
 classify(Panel(int(sys.argv[1]),sys.argv[2]))
