from data import *
from model import sae,spec
import torch,pandas as pd,hashlib,sys
from collections import Counter
def run():
 audit={};sources={};registry=json.load(open('/data/250010109/Research_System/assets/catalog.json'))['assets']
 for k in spec:
  suffix={2:'2b',9:'9b',35:'35b_a3b'}[k];spec[k].update({entry['id']:entry['identity'].get('revision') for entry in registry if entry['id'] in [f'model_qwen35_{suffix}_base',f'sae_qwenscope_qwen35_{suffix}_base_top50']})
 for panel in ['se','arxiv']:
  docs=documents(panel);assert len(set(d['id'] for d in docs))==len(docs);sources[panel]=dict(sha256=hashlib.sha256((R/'docs.json' if panel=='se' else P/'arxiv.json').read_bytes()).hexdigest(),counts=dict(Counter(d['leaf']+'_'+d['split'] for d in docs)))
  for m in [2,9,35]:
   a=Panel(m,panel);r=np.load(P/f'{panel}{m}roles.npz');s=sae(m);w=s['W_dec'];D=len(w);rows=pd.read_csv(P/f'{panel}{m}sir.csv');A=rows[rows.condition=='raw'];errs=[]
   for l in ['QM','AA','GT']:
    ti=a.ids('test',l);t=a.tokens(ti);weights=a.weight(ti);row=A[A.leaf==l].iloc[0];f=int(row.f)
    z=a.Z[t];u=w[:,f]/w[:,f].norm();j=a.j.reshape(-1,50)[t];v=a.v.reshape(-1,50)[t];rec=[];err=0.
    for i in range(0,len(t),32):
     jj=torch.as_tensor(j[i:i+32].astype('int64'),device='cuda');vv=torch.as_tensor(v[i:i+32],device='cuda')
     decoded=(w.T[jj]*vv[:,:,None]).sum(1)+s['b_dec'];rec.extend((decoded@u).cpu().numpy())
     if i==0:
      dense=torch.zeros((len(vv),a.W),device='cuda').scatter_(1,jj,vv);err=(decoded-(dense@w.T+s['b_dec'])).abs().max().item()
      native=dense@w.T+s['b_dec'];masked=dense.clone();masked[:,[]]=0;after=masked@w.T+s['b_dec'];orig=torch.as_tensor(a.ht[a.test_index[ti[0]],:len(vv)],device='cuda');zero=((orig-(native-after))-orig).abs().max().item();assert zero==0
    own=z[:,f].toarray().ravel()*w[:,f].norm().item();other=np.array(rec)-s['b_dec'].dot(u).item()-own
    var=lambda x:weights@((x-weights@x)**2);rel=abs(var(other)/row.I_total-1);assert rel<1e-4,(m,l,rel)
    doc=ti[0];h=a.ht[a.test_index[doc]];assert zero==0
    # Re-encode one genuinely held-out document and check saved Top-50 values.
    ix=np.flatnonzero(a.s=='test').tolist().index(doc);hh=torch.as_tensor(a.ht[ix,:a.n[doc]],device='cuda')
    full=hh@s['W_enc'].T+s['b_enc'];stored=torch.as_tensor(a.j[doc,:a.n[doc]].astype('int64'),device='cuda');delta=(full.gather(1,stored).relu()-torch.as_tensor(a.v[doc,:a.n[doc]],device='cuda')).abs().max().item();assert delta<.005
    kth=full.topk(50).values[:,-1].relu();assert (kth-full.gather(1,stored).relu().min(1).values).abs().max()<.005
    errs.append(dict(leaf=l,doc=docs[doc]['id'],I_total_relative_error=rel,decoder_max_abs=err,zero_removal_max_abs=zero,encoder_max_abs=delta))
   scaled=rows[rows.condition.str.endswith('_random_scaled')];assert np.max(abs(scaled.energy_error_median.dropna()))<2e-5
   geom=pd.read_csv(P/f'{panel}{m}geometry.csv');assert set(geom['rank'])=={8,16,32,64} and geom.coverage.between(0,1).all() and geom.linear_CKA.between(-1e-5,1.0001).all()
   comp=pd.read_csv(P/f'{panel}{m}composition.csv');assert np.allclose(comp.groupby('leaf').share.sum(),1)
   audit[f'{panel}{m}']=errs
 inputs=json.load(open(P/'tasks.json'));te=[x for x in inputs if x['split']=='test'];assert len(te)==64 and len(set(x['doc'] for x in te))==32
 for d in set(x['doc'] for x in te):
  left,right=[x for x in te if x['doc']==d];assert left['answer']!=right['answer'] and left['basis']==right['basis'] and sum(a!=b for a,b in zip(left['ids'],right['ids']))==1
 for m in [2,9,35]:
  rs=pd.read_csv(P/f'output_cov{m}.csv');fin=rs[rs.space=='final_correct_logit'];assert len(fin)==4 and fin.path_max_error.max()<1e-4 and np.allclose(fin.I_total+fin.residual_var+fin.cross_cov,fin.logit_var,rtol=1e-5,atol=1e-5)
  if m in [2,9]:
   new=pd.read_csv(P/f'readout{m}.csv');new=new[new.condition=='raw'].copy();new['style']=[x['style'] for x in te];prev=pd.read_csv(R/f'qm_detail_1125/word_scores{m}.csv');df=new.merge(prev,on=['doc','style','basis','operator'],validate='1:1');assert len(df)==64
   audit[f'dense{m}_native_gap_replay_max_abs']=float((df.native_margin*(2*(df.answer_x=='multiplication')-1)-df.raw_lm_gap).abs().max())
   assert audit[f'dense{m}_native_gap_replay_max_abs']<=.13
 (P/'audit.json').write_text(json.dumps(audit,indent=2));(P/'provenance.json').write_text(json.dumps(dict(models=spec,panels=sources,metadata_revision='d7ceec1703d28b48df136a85510c9ff501fda201',seed=1125),indent=2))
if __name__=='__main__':
 with torch.inference_mode():run()
