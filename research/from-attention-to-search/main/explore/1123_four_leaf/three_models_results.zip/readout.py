from sir import *
from model import Runner
from sklearn.linear_model import LogisticRegression
from scipy.special import expit
def nll(m):return np.logaddexp(0,-m)
def ci(values,docs):
 d=np.unique(docs);v=np.array([np.mean(values[docs==u]) for u in d]);rep=np.random.default_rng(1125).choice(v,(2000,len(v))).mean(1)
 return np.quantile(rep,[.025,.975])
def decomp(effects,j,W):
 z=sparse.csr_matrix((effects.ravel(),j.ravel(),np.arange(0,effects.size+1,50)),shape=(len(j),W))
 w=np.ones(len(j))/len(j);diag=moments(z,w).sum();total=np.var(effects.sum(1));return total,diag,total-diag
@torch.inference_mode()
def run(m):
 eng=Runner(m);s=sae(m);d=s['W_dec'];head=eng.head();tasks=json.load(open(P/'tasks.json'));meta=pd.DataFrame(tasks)
 assert len(set(meta[meta.split=='build'].doc)&set(meta[meta.split=='test'].doc))==0
 for t in tasks:
  tail=eng.tok.encode('\n\n'+t['question'],add_special_tokens=False).ids;assert t['ids'][-len(tail):]==tail
 hidden=np.load(P/f'task_hidden{m}.npy',mmap_mode='r');x=hidden[:,-1].copy();y=np.array(meta.answer=='multiplication',int)
 tr=meta.split=='build';cal=meta.split=='cal';ix=np.flatnonzero(meta.split=='test');docs=meta.doc.values[ix]
 assert len(ix)==64 and len(set(docs))==32
 mu=x[tr].mean(0);scale=np.linalg.norm(x[tr]-mu,axis=1).mean();xx=(x-mu)/scale
 best=None
 for c in [.1,1,10,100,1000,10000]:
  clf=LogisticRegression(C=c,max_iter=2000,random_state=1125).fit(xx[tr],y[tr]);loss=nll((2*y[cal]-1)*clf.decision_function(xx[cal])).mean()
  if best is None or loss<best[0]:best=(loss,c,clf)
 cal_loss,C,clf=best;acc=lambda idx:np.mean(clf.predict(xx[idx])==y[idx]);test_margin=(2*y[ix]-1)*clf.decision_function(xx[ix]);test_loss=nll(test_margin).mean()
 passed=acc(cal)>=.8 and cal_loss<=.45 and acc(ix)>=.8 and test_loss<=.45
 np.savez(P/f'probe{m}.npz',mean=mu,scale=scale,coef=clf.coef_,intercept=clf.intercept_,C=C)
 raw=T(np.array(hidden[ix]));a=np.load(P/f'task{m}.npz');j=a['j'][ix,-1].astype('int64');v=a['v'][ix,-1];parts=d.T[T(j)]*T(v)[:,:,None];G=parts@parts.transpose(1,2)
 fr=np.load(P/f'se{m}roles.npz');role=fr['role'];own=fr['own'];partners=json.load(open(P/f'se{m}partners.json'))['QM'];gen=torch.Generator(device='cuda').manual_seed(1125)
 masks={'raw':np.zeros(j.shape,bool)};ener={'raw':np.zeros(len(j))}
 for nm,mk in {'remove_upper_A':role<=1,'remove_upper_B':fr['B'],'remove_other_leaf':(role==2)&(own!=0),'remove_top_cov_partners':np.isin(np.arange(len(role)),partners)}.items():
  fixed=mk[j]&(v>0);rnd,e,er=random_control(G,fixed,v>0,gen,draws=128);masks[nm]=fixed;masks[nm+'_random']=rnd;ener[nm]=e;ener[nm+'_random']=er
  alpha=np.sqrt(np.divide(e,er,out=np.zeros_like(e),where=er>0));assert np.all((e<=1e-12)|(er>0));masks[nm+'_random_scaled']=rnd*alpha[:,None];ener[nm+'_random_scaled']=er*alpha**2
 rows=[];edits=[];dirs=[];pathidx=[]
 signs=2*y[ix]-1
 for nm,mk in masks.items():
  delta=-(T(mk)[:,:,None]*parts).sum(1);edits.append((raw[:,-1].float()+delta).to(raw.dtype));dirs.append(nm)
 # Return telescoping differences from the real suffix, using the same BF16 boundary as the frozen network.
 cache=P/f'output_cov{m}.csv'
 prior=pd.read_csv(cache) if '--reuse-paths' in sys.argv and cache.exists() else None
 for order in ([] if prior is not None else ['descending','ascending']):
  perm=torch.argsort(T(v),descending=order=='descending',stable=True);increments=torch.gather(parts,1,perm[:,:,None].expand_as(parts)).cumsum(1)
  empty=raw[:,-1]-parts.sum(1);xs=empty[:,None]+increments;xs[:,-1]=raw[:,-1]
  pos=len(edits);edits.append(empty)
  edits.extend(xs[:,k] for k in range(50));pathidx.append((order,pos,perm.cpu().numpy()))
 b=len(ix);H=raw.to(torch.bfloat16).repeat(len(edits),1,1);H[:,-1]=torch.cat(edits).to(H.dtype); del edits
 logits=eng.layers(H,eng.L+1,len(eng.model.layers));eng.mount(eng.model.norm,'norm');out=(eng.model.norm(logits[:,-1])@head.T).float().cpu().numpy().reshape(-1,b,2);del H,logits
 readrows=[]; label=np.where(y[ix],0,1);raw_logits=out[0,np.arange(b),label]
 for ni,(nm,mk) in enumerate(masks.items()):
  cut=(T(mk)[:,:,None]*parts).sum(1).cpu().numpy();new_x=x[ix]-cut;delta_pr=(2*y[ix]-1)*clf.decision_function((new_x-mu)/scale)
  lm=signs*(out[ni,:,0]-out[ni,:,1]);delta=out[ni,np.arange(b),label]-raw_logits
  prloss=nll(delta_pr) if passed or nm=='raw' else np.full(b,np.nan)
  for i,t in enumerate(ix):
   rows.append(dict(model=m,condition=nm,doc=docs[i],basis=meta.basis[t],operator=meta.operator[t],answer=meta.answer[t],question=meta.question[t],raw_probe_gate=passed,cal_accuracy=acc(cal),cal_nll=cal_loss,C=C,probe_acc=float(delta_pr[i]>0) if passed or nm=='raw' else np.nan,probe_nll=prloss[i],native_margin=lm[i],native_acc=float(lm[i]>0),native_nll=nll(lm[i]),correct_logit=out[ni,i,label[i]],removed_energy=ener[nm][i]))
  coeff=(parts*head.float()[T(label)][:,None,:]).sum(2).cpu().numpy()*(1-mk.astype(float));unproj=-(cut*head.float().cpu().numpy()[label]).sum(1)
  for k in [0,1]:
   ids=label==k;total,diag,off=decomp(coeff[ids],j[ids],len(role));readrows.append(dict(model=m,condition=nm,space='middle_unembedding',order='linear',answer=['multiplication','differentiation'][k],I_total=total,I_diag=diag,I_off=off,amplification=total/diag,logit_change_corr=np.corrcoef(delta[ids],unproj[ids])[0,1] if np.std(delta[ids])*np.std(unproj[ids]) else np.nan))
 for order,start,perm in pathidx:
  path=out[start:start+51,np.arange(b),label].T;diff=np.diff(path,axis=1);js=np.take_along_axis(j,perm,axis=1);error=np.max(np.abs(diff.sum(1)-(raw_logits-path[:,0])));assert error<1e-4,error
  for k in [0,1]:
   ids=label==k;total,diag,off=decomp(diff[ids],js[ids],len(role));rr=path[ids,0];eff=diff[ids].sum(1);cross=2*np.mean((eff-eff.mean())*(rr-rr.mean()))
   readrows.append(dict(model=m,condition='raw',space='final_correct_logit',order=order,answer=['multiplication','differentiation'][k],I_total=total,I_diag=diag,I_off=off,amplification=total/diag,path_max_error=error,residual_var=np.var(rr),cross_cov=cross,logit_var=np.var(raw_logits[ids])))
 if prior is not None:readrows.extend(prior[prior.space=='final_correct_logit'].to_dict('records'))
 pd.DataFrame(rows).to_csv(P/f'readout{m}.csv',index=False);pd.DataFrame(readrows).to_csv(P/f'output_cov{m}.csv',index=False);print('gate',passed,acc(cal),cal_loss,acc(ix),test_loss,flush=True)
if __name__=='__main__':run(int(sys.argv[1]))
