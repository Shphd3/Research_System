from data import *
import pandas as pd
def run():
 rows=[];entropy=[];bs=np.random.default_rng(1125).multinomial(32,np.ones(32)/32,size=(1500,4))/32
 for p in ['se','arxiv']:
  rates={}
  for m in [2,9,35]:
   a=Panel(m,p);r=np.load(P/f'{p}{m}roles.npz');role=r['role'];rates[m]=[]
   for l in LEAVES:
    dl=[]
    for ix in a.ids('test',l):
     tok=a.j[ix,:a.n[ix]];v=a.v[ix,:a.n[ix]];ev=np.bincount(role[tok][v>0],minlength=5);dl.append(ev/ev.sum())
    rates[m].append(dl)
   rates[m]=np.array(rates[m]);df=pd.read_csv(P/f'{p}{m}entropy.csv.gz')
   for threshold in [1,5,20]:
    for scope,d in [('other_supported',df),('strict_cross_domain',df[df.strict])]:
     d=d[d.hits>=threshold];q=d.test_entropy.quantile([.25,.5,.75]).values;entropy.append(dict(model=m,panel=p,scope=scope,min_test_hits=threshold,features=len(d),events=d.hits.sum(),q25=q[0],median=q[1],q75=q[2]))
  for m in [2,9]:
   diff=rates[35]-rates[m];dist=np.einsum('bld,ldk->bk',bs,diff)/4
   for k,g in enumerate(CATS):
    lo,hi=np.quantile(dist[:,k],[.025,.975]);rows.append(dict(panel=p,comparison=f'35B minus {m}B',group=g,difference_pp=100*diff[:,:,k].mean(),lo_pp=100*lo,hi_pp=100*hi))
 pd.DataFrame(rows).to_csv(P/'composition_intervals.csv',index=False);pd.DataFrame(entropy).to_csv(P/'entropy_summary.csv',index=False)
if __name__=='__main__':run()
