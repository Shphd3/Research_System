from model import P,R,documents
import numpy as np, json
from scipy import sparse
LEAVES=['QM','SM','AA','GT']
CATS=['root','parent','leaf','soft_shared','low_support']
def pack_dense(m):
 docs=documents('se'); vals=[];indices=[];hs=[];ht=[];lens=[]
 for d in docs:
  with np.load(R/f'cache{m}'/(d['id']+'.npz')) as z:
   h=z['h'];n=len(h);lens.append(n);hs.append(h[[24,32,40,48]]);vals.append(np.pad(z['v'],((0,64-n),(0,0))));indices.append(np.pad(z['j'].astype('uint16'),((0,64-n),(0,0))))
   if d['split']=='test':ht.append(np.pad(h,((0,64-n),(0,0))))
 np.savez(P/f'se{m}.npz',v=vals,j=indices,length=lens,h4=hs,testh=ht)
class Panel:
 def __init__(self,m,panel):
  self.docs=documents(panel);self.m=m;self.panel=panel;self.W=65536 if m==9 else 32768
  with np.load(P/f'{panel}{m}.npz') as f:self.j,self.v,self.n,self.h4,self.ht=[f[k] for k in ['j','v','length','h4','testh']]
  self.s=np.array([d['split'] for d in self.docs]);self.l=np.array([d['leaf'] for d in self.docs]);self.test_index=np.cumsum(self.s=='test')-1
  self.Z=self.csr(self.j,self.v);self.X=self.Z.copy();self.X.data[:]=1
 def csr(self,j,v):
  n=v.size//50;z=sparse.csr_matrix((v.ravel().copy(),j.astype('int32').ravel(),np.arange(0,n*50+1,50)),shape=(n,self.W));z.eliminate_zeros();return z
 def ids(self,split,leaf=None):return np.flatnonzero((self.s==split)&((self.l==leaf) if leaf else True))
 def tokens(self,ids):return np.concatenate([np.arange(i*64,i*64+self.n[i]) for i in ids])
 def weight(self,ids):return np.repeat(1/(len(ids)*self.n[ids]),self.n[ids])
 def counts(self,ids):
  t=self.tokens(ids);x=self.X[t];return np.asarray(x.sum(0)).ravel(), x.T@self.weight(ids)
if __name__=='__main__':
 import sys
 pack_dense(int(sys.argv[1]))
