from pathlib import Path
import sys,json,importlib.util
import torch,numpy as np
from safetensors import safe_open
from tokenizers import Tokenizer
find=importlib.util.find_spec
importlib.util.find_spec=lambda n,*a,**kw:None if n.split('.')[0] in {'torchvision','torchaudio','librosa','flash_attn','flash_attn_2_cuda','apex','causal_conv1d','fla'} else find(n,*a,**kw)
from transformers.models.qwen3_5.modeling_qwen3_5 import Qwen3_5TextConfig,Qwen3_5TextModel
from transformers.models.qwen3_5_moe.modeling_qwen3_5_moe import Qwen3_5MoeTextConfig,Qwen3_5MoeTextModel,create_causal_mask
P=Path(__file__).resolve().parent
R=P.parent
Q=Path('/mnt/bucket/109_cache_dir/model_cache/Qwen')
spec={}
for m,name,L,w in [(2,'2B',11,32),(9,'9B',15,64),(35,'35B-A3B',19,32)]:
 name=f'Qwen3.5-{name}-Base';spec[m]=dict(model=str(Q/name),layer=L,sae=str(Q/f'SAE-Res-{name}-W{w}K-L0_50'/f'layer{L}.sae.pt'),hook='resid_post',topk=50)
def sae(m,device='cuda'):
 return torch.load(spec[m]['sae'],map_location=device,weights_only=True)
class Runner:
 def __init__(self,m):
  self.m=m; self.path=Path(spec[m]['model']);self.L=spec[m]['layer'];self.idx=json.load(open(self.path/'model.safetensors.index.json'))['weight_map']
  C,M=(Qwen3_5MoeTextConfig,Qwen3_5MoeTextModel) if m==35 else (Qwen3_5TextConfig,Qwen3_5TextModel)
  self.cfg=C(**json.load(open(self.path/'config.json'))['text_config']); self.cfg._attn_implementation='eager'
  if m==35:self.cfg._experts_implementation='grouped_mm'
  with torch.device('meta'):self.model=M(self.cfg)
  self.model.eval();self.rot=type(self.model.rotary_emb)(config=self.cfg,device='cuda')
  self.tok=Tokenizer.from_file(str(self.path/'tokenizer.json'))
 def tensor(self,key,rows=None):
  f=Path('/tmp/qm_three_weights')/self.path.name/self.idx[key]
  if not f.exists():f=self.path/self.idx[key]
  with safe_open(str(f),framework='pt') as src:
   t=src.get_tensor(key)
   if rows is not None:t=t[rows]
   return t.cuda()
 def mount(self,module,prefix):
  module.load_state_dict({k:self.tensor('model.language_model.'+prefix+'.'+k) for k in module.state_dict()},assign=True)
 def layers(self,h,start,end):
  for i in range(start,end):
   block=self.model.layers[i];self.mount(block,f'layers.{i}')
   for x in h.split(16):
    pos=torch.arange(x.shape[1],device='cuda'); pid=pos[None,None,:].expand(3,len(x),-1)
    mask=create_causal_mask(config=self.cfg,inputs_embeds=x,attention_mask=None,cache_position=pos,past_key_values=None,position_ids=pid[0]) if block.layer_type=='full_attention' else None
    x.copy_(block(x,position_embeddings=self.rot(x,pid),attention_mask=mask,position_ids=pid,past_key_values=None,use_cache=False,cache_position=pos))
   block.to_empty(device='meta');print('layer',self.m,i,len(h),flush=True)
  return h
 def head(self):
  ids=[self.tok.encode(t,add_special_tokens=False).ids for t in [' multiplication',' differentiation']];assert all(len(x)==1 for x in ids)
  return self.tensor('lm_head.weight' if 'lm_head.weight' in self.idx else 'model.language_model.embed_tokens.weight',[x[0] for x in ids])
def tasks(tok):
 items=json.load(open(R/'qm_detail_1125/word_prompts2.json'));docs=json.load(open(R/'docs.json')); tests=sorted({x['doc'] for x in items if x['split']=='test'}); builds=sorted({x['doc'] for x in items if x['split']=='build'})
 selected=[]
 for x in items:
  if x['split']=='test':
   k=tests.index(x['doc'])
   if x['style']!=k%2 or x['basis']!=['x','p'][(k//2)%2]:continue
  elif x['doc'] in builds[-8:]:x=dict(x,split='cal')
  selected.append(x)
 return selected
def documents(panel):return json.load(open(R/'docs.json' if panel=='se' else P/'arxiv.json'))
def encode(h,s):
 v,j=(h.float()@s['W_enc'].T+s['b_enc']).topk(50);return v.relu(),j
@torch.inference_mode()
def extract(m,panels):
 eng=Runner(m); ids=[];slices={};lens={};all_docs={}
 for panel in panels:
  if panel=='task':
   ds=tasks(eng.tok);seq=[x['ids'] for x in ds]
   (P/'tasks.json').write_text(json.dumps(ds))
  else:
   ds=documents(panel);seq=[eng.tok.encode(x['text'],add_special_tokens=False).ids[:64] for x in ds]
  lens[panel]=list(map(len,seq));slices[panel]=slice(len(ids),len(ids)+len(ds));ids.extend([x+[0]*(64-len(x)) for x in seq]);all_docs[panel]=ds
 idx=torch.tensor(ids,device='cuda'); h=torch.nn.functional.embedding(idx,eng.tensor('model.language_model.embed_tokens.weight'));eng.layers(h,0,eng.L+1)
 s=sae(m)
 for panel,sl in slices.items():
  g=h[sl]; vs=[];js=[]
  if panel=='task':np.save(P/f'task_hidden{m}.npy',g.float().cpu().numpy())
  for batch in g.split(8):
   v,j=encode(batch,s);assert v.isfinite().all() and batch.isfinite().all();vs.append(v.cpu().numpy());js.append(j.cpu().numpy().astype('uint16'))
  np.savez(P/f'{panel}{m}.npz',v=np.concatenate(vs),j=np.concatenate(js),length=lens[panel],h4=g[:,[24,32,40,48]].float().cpu().numpy(),testh=g[[i for i,d in enumerate(all_docs[panel]) if d['split']=='test']].float().cpu().numpy())
 np.save(P/f'head{m}.npy',eng.head().float().cpu().numpy())
if __name__=='__main__':
 (P/'config.json').write_text(json.dumps(spec,indent=2));extract(int(sys.argv[1]),sys.argv[2:])
