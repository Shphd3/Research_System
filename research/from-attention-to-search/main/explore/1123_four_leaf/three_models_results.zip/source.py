from pathlib import Path
import requests,hashlib,json,random,re,time
import pyarrow.parquet as pq
P=Path(__file__).resolve().parent
rev='d7ceec1703d28b48df136a85510c9ff501fda201'
base='https://huggingface.co/datasets/bluuebunny/arxiv_metadata_by_year/resolve/'+rev+'/data/'
pools={k:[] for k in ['QM','SM','AA','GT']}
for year in ['19','18','17','20']:
 f=Path('/tmp')/('qm_arxiv_'+year+'.parquet')
 if not f.exists():
  for attempt in range(4):
   try:
    with requests.get(base+year+'.parquet',stream=True,timeout=60,params={'download':'true','v':str(time.time())}) as r:
     r.raise_for_status()
     with f.with_suffix('.tmp').open('wb') as out:
      for b in r.iter_content(1<<20):out.write(b)
    pq.ParquetFile(f.with_suffix('.tmp'));f.with_suffix('.tmp').rename(f);break
   except Exception as e: print(e,flush=True)
 pf=pq.ParquetFile(f); print(year,pf.schema.names,flush=True)
 for batch in pf.iter_batches(batch_size=1024,columns=['id','title','abstract','categories']):
  for d in batch.to_pylist():
   cats=d['categories'];cats=cats.split() if isinstance(cats,str) else cats
   tags={'quant-ph':'QM','cond-mat.stat-mech':'SM','math.RA':'AA','math.GR':'AA','math.CO':'GT'}
   if not cats or cats[0] not in tags:continue
   leaf=tags[cats[0]]
   if len({tags[k] for k in cats if k in tags})!=1:continue
   if leaf=='GT' and not re.search(r'\bgraphs?\b',d['title'],re.I):continue
   t=re.sub(r'https?://\S+|quantum mechanics|statistical mechanics|abstract algebra|graph theory',' ',d['abstract'],flags=re.I)
   t=' '.join(t.split()); w=re.findall('[a-z]{2,}',t.lower())
   if len(w)<45:continue
   pools[leaf].append(dict(id='arx-'+str(d['id']),site='arxiv',leaf=leaf,text=t,tags=cats))
 print({k:len(v) for k,v in pools.items()},flush=True)
 if min(map(len,pools.values()))>=350:break
out=[];hist=[];seen=set();rng=random.Random(1125)
for leaf,rows in pools.items():
 rng.shuffle(rows);sel=[]
 for d in rows:
  words=re.findall('[a-z]{2,}',d['text'].lower());g=set(zip(words,words[1:],words[2:]))
  if d['id'] in seen or any(len(g&h)>.45/1.45*(len(g)+len(h)) for h in hist):continue
  hist.append(g);seen.add(d['id']);sel.append(d)
  if len(sel)==320:break
 assert len(sel)==320,(leaf,len(sel))
 out += [dict(d,split='build' if i<256 else 'cal' if i<288 else 'test') for i,d in enumerate(sel)]
(P/'arxiv.json').write_text(json.dumps(out));print('done',len(out))
