#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source ../../confirm/env.sh
python stage.py
if [[ ! -s arxiv.json ]]; then python source.py; fi
for m in 2 9 35; do
 if [[ $m = 35 ]]; then python model.py "$m" se arxiv task; else python data.py "$m"; python model.py "$m" arxiv task; fi
 for panel in se arxiv; do
  python roles.py "$m" "$panel"
  python sir.py "$m" "$panel"
  python geometry.py "$m" "$panel"
  python geometry.py "$m" "$panel" extra
 done
 python readout.py "$m"
done
python composition_check.py
python assemble.py
python audit.py
python report.py
