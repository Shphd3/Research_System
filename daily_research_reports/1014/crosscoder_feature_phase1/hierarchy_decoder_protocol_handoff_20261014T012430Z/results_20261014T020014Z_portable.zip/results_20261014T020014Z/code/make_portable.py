import json,hashlib,zipfile,time,posixpath,re,datetime
from pathlib import Path
r=Path('/data/250010109/MoE_Router/experiments/20261012_qwen3_crosscoder/analysis/hierarchy_decoder_distribution/20261014T020014Z');plan=json.loads((r/'execution_record.json').read_text());d=Path(plan['delivery_root']);old=json.loads((r/'archive_receipt.json').read_text());archive=Path(old['archive_path']);start=time.monotonic();anchor=Path(plan['protocol']).parent/'hierarchy_decoder_distribution_anchor_user_20261014_cn.md';files={str(p.relative_to(d)):(p,p.read_bytes()) for p in d.rglob('*') if p.is_file() and p.name!='payload_manifest.json'};files['provenance/canonical_payload_manifest.json']=(d/'payload_manifest.json',(d/'payload_manifest.json').read_bytes());files['provenance/anchor_cn.md']=(anchor,anchor.read_bytes());files['code/make_portable.py']=(Path(__file__),Path(__file__).read_bytes());records=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
 for rel,(source,raw) in sorted(files.items()):
  payload=raw
  if rel.endswith('.md'):
   text=raw.decode();parent=posixpath.dirname(rel) or '.'
   def target(m):
    value=m.group(1)
    if value.startswith(str(d)+'/'):value=posixpath.relpath(value[len(str(d))+1:],parent)
    elif value==str(anchor):value=posixpath.relpath('provenance/anchor_cn.md',parent)
    return ']('+value+')'
   payload=re.sub(r'\]\(([^)]+)\)',target,text).encode()
  z.writestr(str(Path(d.name)/rel),payload)
  records.append({'relative_path':rel,'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),'canonical_origin':str(source),'canonical_sha256':hashlib.sha256(raw).hexdigest(),'only_internal_markdown_links_rewritten':payload!=raw})
 manifest={'files':records,'execution_root':str(r),'original_input_root':plan['source_root'],'portability':'Internal Markdown links are relative; original external execution/data paths remain absolute provenance. No model weights or full activation cache included.','scientific_tables_and_figures_unchanged':True,'producer':str(Path(__file__))};z.writestr(str(Path(d.name)/'payload_manifest.json'),json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name in z.namelist():
  if name.endswith('.md'):
   text=z.read(name).decode()
   for target in re.findall(r'\]\(([^)]+)\)',text):
    if not target.startswith(('/','http:','https:','#')):
     full=posixpath.normpath(posixpath.join(posixpath.dirname(name),target))
     assert full in z.namelist(),(name,target)
receipt={'archive_path':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'packaging_seconds':time.monotonic()-start,'initial_packaging_seconds':old['packaging_seconds'],'previous_archive_sha256':old['sha256'],'change':'Portable internal Markdown links, original Anchor copy and checked archive manifest; statistics and figures unchanged','zip_crc_and_internal_links':'PASS','final_verified_beijing':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),'wall_seconds_since_run_record':(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(plan['created_utc'])).total_seconds(),'total_new_disk_bytes':sum(p.stat().st_size for root in [r,d] for p in root.rglob('*') if p.is_file())+archive.stat().st_size,'active_compute_accounted_upper_bound_seconds':64.12945006415248+5.096081839874387+2.7869402188807726+130+old['packaging_seconds']+time.monotonic()-start,'active_bound_note':'Includes conservative 130s charge for stopped validator; exact failed-check duration unknown. Document writing excluded.'};assert receipt['total_new_disk_bytes']<1<<30 and receipt['wall_seconds_since_run_record']<5400 and receipt['active_compute_accounted_upper_bound_seconds']<1800
for p in [r/'archive_receipt.json',d.parent/(d.name+'_archive_receipt.json')]:p.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
