# 阅读入口

先读[简短中文结论](summary_cn.md)，再读[完整中文报告](detailed_cn.md)。

[三类图及读图说明](figures_cn.md)；[全部源表索引](tables_cn.md)；[全部随机／高激活文本](text_examples_cn.md)。同一目录含CSV、JSONL、PNG/PDF/SVG及来源／代码，数据与图可携带。

结果：整体平均位置关系不支持原正向预期；分布浅深并存；频率比较混合。任务pt-icv8hyi3已成功结束。没有训练、推理、全量共现计数或重建图。科学判断及下一步待研究者讨论。
